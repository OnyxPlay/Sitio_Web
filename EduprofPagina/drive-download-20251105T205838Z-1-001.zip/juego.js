// Array para manejar los datos de vocabulario (lista interactiva como "productos" o "tareas" educativas)
let vocabulary = [];

// Función para inicializar datos de ejemplo
function initializeVocabulary() {
    // Ejemplos temáticos para el juego Shooter English
    vocabulary = [
        { word: 'Shoot', translation: 'Disparar', level: 'Beginner' },
        { word: 'Enemy', translation: 'Enemigo', level: 'Intermediate' },
        { word: 'Level up', translation: 'Subir de nivel', level: 'Advanced' }
    ];
    displayVocabulary();
    updateCount();
}

// Función para agregar un item al array
function addVocabulary() {
    const wordInput = document.getElementById('wordInput');
    const translationInput = document.getElementById('translationInput');
    const levelSelect = document.getElementById('levelSelect');
    
    const word = wordInput.value.trim();
    const translation = translationInput.value.trim();
    const level = levelSelect.value;
    
    if (word === '' || translation === '') {
        alert('Por favor, ingresa una palabra en inglés y su traducción.');
        return;
    }
    
    // Agregar al array como objeto
    vocabulary.push({
        word: word,
        translation: translation,
        level: level
    });
    
    // Limpiar inputs
    wordInput.value = '';
    translationInput.value = '';
    
    // Actualizar vista y contador
    displayVocabulary();
    updateCount();
    
    // Opcional: Guardar en localStorage para persistencia
    localStorage.setItem('shooterVocabulary', JSON.stringify(vocabulary));
}

// Función para mostrar la lista del array en el DOM
function displayVocabulary() {
    const listContainer = document.getElementById('vocabularyList');
    listContainer.innerHTML = '';  // Limpiar lista anterior
    
    vocabulary.forEach((item, index) => {
        const div = document.createElement('div');
        div.className = 'vocabulary-item';
        div.innerHTML = `
            <span><strong>${item.word}</strong> - ${item.translation} (Nivel: ${item.level})</span>
            <button onclick="deleteVocabulary(${index})" style="background: var(--color-terciario); color: var(--color-texto); border: none; padding: 5px 10px; margin-left: 10px; cursor: pointer;">Eliminar</button>
        `;
        listContainer.appendChild(div);
    });
}

// Función para eliminar un item del array por índice
function deleteVocabulary(index) {
    if (confirm(`¿Eliminar "${vocabulary[index].word}" de tu lista de vocabulario?`)) {
        vocabulary.splice(index, 1);  // Remover del array
        displayVocabulary();
        updateCount();
        
        // Actualizar localStorage
        localStorage.setItem('shooterVocabulary', JSON.stringify(vocabulary));
    }
}

// Función para actualizar el contador de items
function updateCount() {
    const countElement = document.getElementById('vocabularyCount');
    countElement.textContent = vocabulary.length;
}

// Función para crear la sección interactiva dinámicamente
function createInteractiveSection() {
    // Crear el contenedor principal de la sección
    const section = document.createElement('section');
    section.id = 'vocabularySection';
    section.className = 'vocabulary-interactive';
    section.innerHTML = `
        <h2 style="color: var(--color-secundario); text-align: center; margin-bottom: 20px;">Vocabulario Interactivo - ¡Aprende Disparando!</h2>
        <p style="text-align: center; margin-bottom: 20px; color: var(--color-texto);">Agrega palabras en inglés relacionadas con el juego. ¡Practica tu vocabulario como en Shooter English!</p>
        
        <!-- Formulario para agregar -->
        <div style="background: var(--color-fondo-claro); padding: 20px; border-radius: 10px; margin-bottom: 20px; text-align: center;">
            <input type="text" id="wordInput" placeholder="Palabra en inglés (ej: Shoot)" style="padding: 10px; margin: 5px; border-radius: 5px; border: 1px solid var(--color-secundario); width: 200px;" />
            <input type="text" id="translationInput" placeholder="Traducción al español (ej: Disparar)" style="padding: 10px; margin: 5px; border-radius: 5px; border: 1px solid var(--color-secundario); width: 200px;" />
            <select id="levelSelect" style="padding: 10px; margin: 5px; border-radius: 5px; border: 1px solid var(--color-secundario);">
                <option value="Beginner">Principiante</option>
                <option value="Intermediate">Intermedio</option>
                <option value="Advanced">Avanzado</option>
            </select>
            <br>
            <button onclick="addVocabulary()" style="background: var(--color-secundario); color: var(--color-texto); border: none; padding: 10px 20px; margin-top: 10px; border-radius: 5px; cursor: pointer; font-size: 1em;">Agregar Palabra</button>
        </div>
        
        <!-- Lista de vocabulario -->
        <div style="background: var(--color-fondo-claro); padding: 20px; border-radius: 10px; border-left: 5px solid var(--color-terciario);">
            <h3 style="color: var(--color-secundario); margin-bottom: 10px;">Tu Lista de Vocabulario (${vocabulary.length} items)</h3>
            <div id="vocabularyList" style="max-height: 300px; overflow-y: auto;"></div>
            <p style="text-align: center; margin-top: 10px; font-size: 0.9em; color: var(--color-texto);">Palabras activas: <span id="vocabularyCount">0</span></p>
        </div>
        
        <style>
            .vocabulary-item {
                background: rgba(255, 255, 255, 0.1);
                padding: 10px;
                margin: 5px 0;
                border-radius: 5px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                color: var(--color-texto);
            }
            .vocabulary-item button:hover {
                background: var(--color-principal);
            }
            @media (max-width: 768px) {
                #wordInput, #translationInput { width: 100%; box-sizing: border-box; }
            }
        </style>
    `;
    
    // Insertar la sección después de las features (buscar el elemento .features)
    const featuresSection = document.querySelector('.features');
    if (featuresSection) {
        featuresSection.insertAdjacentElement('afterend', section);
    } else {
        // Si no se encuentra, insertar al final del main
        const main = document.querySelector('main');
        main.appendChild(section);
    }
    
    // Cargar desde localStorage si existe
    const saved = localStorage.getItem('shooterVocabulary');
    if (saved) {
        vocabulary = JSON.parse(saved);
        displayVocabulary();
        updateCount();
    } else {
        initializeVocabulary();
    }
}

// Inicializar todo al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar la sección interactiva
    createInteractiveSection();

    // Configurar el menú desplegable
    const menuBtn = document.querySelector('.menu-btn');
    const dropdownContent = document.querySelector('.dropdown-content');

    menuBtn.addEventListener('click', function(e) {
        e.stopPropagation(); // Evita que se cierre al hacer clic en el botón
        dropdownContent.style.display = 
            dropdownContent.style.display === 'block' ? 'none' : 'block';
    });

    // Cerrar el menú si se hace clic fuera
    document.addEventListener('click', function(e) {
        if (!menuBtn.contains(e.target) && !dropdownContent.contains(e.target)) {
            dropdownContent.style.display = 'none';
        }
    });
});
